<h3>Sobre</h3>

<li>
    <a href="{{ route('site.index') }}">Index</a>
</li>
<li>
    <a href="{{ route('site.sobre') }}">Sobre</a>
</li>
<li>
    <a href="{{ route('site.contato') }}">Contato</a>
</li>