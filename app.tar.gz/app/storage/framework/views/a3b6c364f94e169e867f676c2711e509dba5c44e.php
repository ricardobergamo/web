<h3>Contato</h3>

<li>
    <a href="<?php echo e(route('site.index')); ?>">Index</a>
</li>
<li>
    <a href="<?php echo e(route('site.sobre')); ?>">Sobre</a>
</li>
<li>
    <a href="<?php echo e(route('site.contato')); ?>">Contato</a>
</li><?php /**PATH /home/ricardo/development/laravel/app/resources/views/site/contato.blade.php ENDPATH**/ ?>